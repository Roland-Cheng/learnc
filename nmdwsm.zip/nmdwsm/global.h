#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include<stdio.h>
#include<iostream>
#include<math.h>
#include<time.h>

#endif // !_GLOBAL_H_

